import Jornada from '../../pages/Jornada'

export default function JornadaExample() {
  return <Jornada />
}
