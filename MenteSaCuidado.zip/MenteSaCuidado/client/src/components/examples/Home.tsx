import Home from '../../pages/Home'

export default function HomeExample() {
  return <Home />
}
