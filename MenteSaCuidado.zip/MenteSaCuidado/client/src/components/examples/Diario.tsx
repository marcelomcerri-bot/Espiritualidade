import Diario from '../../pages/Diario'

export default function DiarioExample() {
  return <Diario />
}
