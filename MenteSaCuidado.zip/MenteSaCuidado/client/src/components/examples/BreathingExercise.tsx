import BreathingExercise from '../BreathingExercise'

export default function BreathingExerciseExample() {
  return <BreathingExercise />
}
