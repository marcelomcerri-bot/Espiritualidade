import Referencias from '../../pages/Referencias'

export default function ReferenciasExample() {
  return <Referencias />
}
