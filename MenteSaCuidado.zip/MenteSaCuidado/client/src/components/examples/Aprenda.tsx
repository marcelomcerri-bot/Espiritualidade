import Aprenda from '../../pages/Aprenda'

export default function AprendaExample() {
  return <Aprenda />
}
