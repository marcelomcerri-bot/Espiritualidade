import Praticas from '../../pages/Praticas'

export default function PraticasExample() {
  return <Praticas />
}
