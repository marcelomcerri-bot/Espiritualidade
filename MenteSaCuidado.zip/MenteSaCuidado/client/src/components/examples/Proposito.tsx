import Proposito from '../../pages/Proposito'

export default function PropositoExample() {
  return <Proposito />
}
