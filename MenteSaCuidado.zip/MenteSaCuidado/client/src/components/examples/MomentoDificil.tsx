import MomentoDificil from '../../pages/MomentoDificil'

export default function MomentoDificilExample() {
  return <MomentoDificil />
}
