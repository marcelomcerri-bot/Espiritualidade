import MapaSentido from '../../pages/MapaSentido'

export default function MapaSentidoExample() {
  return <MapaSentido />
}
